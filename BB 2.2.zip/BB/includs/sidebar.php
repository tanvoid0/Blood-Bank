<ul class="navbar-nav navbar-sidenav" id="exampleAccordion">
  <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Dashboard">
    <a class="nav-link" href="dashboard.php">
      <i class="fa fa-fw fa-dashboard"></i>
      <span class="nav-link-text">Dashboard</span>
    </a>
  </li>
  <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Projects">
    <a class="nav-link" href="donors.php">
      <i class="fa fa-clipboard" aria-hidden="true"></i>
      <span class="nav-link-text">Blood Donors</span>
    </a>
  </li>
</ul>
